-- Lawly · Supabase schema
-- Paste this into Supabase SQL Editor → Run

-- ─────────────────────────────────────────────────────────────
-- scans table
-- Stores every audit result. The full report lives in `payload`
-- as JSONB so future schema changes don't require migrations.
-- ─────────────────────────────────────────────────────────────

create table if not exists public.scans (
  id              text         primary key,
  hostname        text         not null,
  url             text         not null,
  grade           text         not null,
  score           integer      not null,
  total_findings  integer      not null default 0,
  duration_ms     integer      not null default 0,
  payload         jsonb        not null,
  user_id         uuid         references auth.users(id) on delete set null,
  created_at      timestamptz  not null default now()
);

create index if not exists scans_hostname_idx on public.scans (hostname);
create index if not exists scans_created_at_idx on public.scans (created_at desc);
create index if not exists scans_user_id_idx on public.scans (user_id);

-- ─────────────────────────────────────────────────────────────
-- Row-Level Security
-- For v1 (anonymous scans), the service role bypasses RLS so the
-- Next.js API route can write without auth. We expose READS publicly
-- so anyone with the scan ID can view the report (Reddit-friendly).
-- Tighten this once auth is added.
-- ─────────────────────────────────────────────────────────────

alter table public.scans enable row level security;

-- Anyone can read a scan if they know the ID
create policy "Public can read scans" on public.scans
  for select using (true);

-- Service role writes (used by /api/scan)
create policy "Service can insert scans" on public.scans
  for insert with check (true);

-- ─────────────────────────────────────────────────────────────
-- Future: a user can claim ownership of anonymous scans by
-- updating user_id after signup. Add a trigger or RPC later.
-- ─────────────────────────────────────────────────────────────
