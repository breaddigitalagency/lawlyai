import { notFound } from 'next/navigation';
import Link from 'next/link';
import { getScan } from '@/lib/storage';
import { Nav } from '@/components/nav';
import { Footer } from '@/components/final-cta';
import type { Finding, BucketResult } from '@/lib/types';

const BUCKET_LABEL: Record<string, string> = {
  pages: 'Required pages',
  policies: 'Policy gaps',
  claims: 'Ad & copy risk',
  tracking: 'Tracking & consent',
};

const SEV_COLOR: Record<string, string> = {
  critical: 'bg-oxide text-bone',
  high: 'bg-oxide/15 text-oxide border border-oxide/30',
  med: 'bg-gold/20 text-gold-deep border border-gold/30',
  low: 'bg-ink/10 text-ink-soft border border-ink/15',
  info: 'bg-ink/5 text-ink-soft',
};

const SEV_ORDER = { critical: 0, high: 1, med: 2, low: 3, info: 4 } as const;

export default async function ScanPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const scan = await getScan(id);

  if (!scan) notFound();

  const allFindings = scan.buckets
    .flatMap((b) => b.findings)
    .sort((a, b) => SEV_ORDER[a.severity] - SEV_ORDER[b.severity]);

  const critCount = allFindings.filter((f) => f.severity === 'critical').length;
  const highCount = allFindings.filter((f) => f.severity === 'high').length;
  const medCount = allFindings.filter((f) => f.severity === 'med').length;
  const lowCount = allFindings.filter((f) => f.severity === 'low').length;

  return (
    <>
      <Nav />
      <main className="pb-32">
        {/* Report header — feels like a legal document cover */}
        <section className="border-b border-ink/15 bg-surface-warm">
          <div className="container-edge py-12 md:py-16">
            <div className="flex items-center gap-3 mb-8">
              <span className="tag">Lawly · Confidential audit</span>
              <div className="flex-1 rule" />
              <span className="font-mono text-xs text-muted">
                {scan.id.toUpperCase()}
              </span>
            </div>

            <div className="grid grid-cols-12 gap-8">
              <div className="col-span-12 lg:col-span-7">
                <div className="tag mb-3">Target</div>
                <h1 className="font-serif text-display-md text-balance break-all">
                  {scan.hostname}
                </h1>
                <a
                  href={scan.url}
                  target="_blank"
                  rel="noopener noreferrer nofollow"
                  className="inline-flex items-center gap-2 mt-3 font-mono text-sm text-muted hover:text-oxide transition-colors"
                >
                  {scan.url} ↗
                </a>
              </div>

              <div className="col-span-12 lg:col-span-5 grid grid-cols-2 gap-6">
                <StatCard label="Grade" value={scan.grade} accent />
                <StatCard label="Score" value={`${scan.score}`} suffix="/ 100" />
                <StatCard label="Findings" value={`${scan.totalFindings}`} />
                <StatCard
                  label="Scan time"
                  value={`${(scan.durationMs / 1000).toFixed(1)}s`}
                />
              </div>
            </div>

            {/* Meta strip */}
            <div className="mt-10 pt-6 border-t border-ink/10 grid grid-cols-2 md:grid-cols-4 gap-6 text-sm">
              <MetaItem
                label="Platform"
                value={scan.meta.platform || 'Custom / unknown'}
              />
              <MetaItem
                label="Jurisdiction"
                value={scan.meta.detectedJurisdiction?.join(' · ') || '—'}
              />
              <MetaItem label="Pages fetched" value={`${scan.meta.pagesFetched}`} />
              <MetaItem
                label="Filed"
                value={new Date(scan.finishedAt).toLocaleString('en-AU')}
              />
            </div>
          </div>
        </section>

        {/* Severity summary */}
        <section className="border-b border-ink/15">
          <div className="container-edge py-10">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-ink/15">
              <SevTile severity="critical" count={critCount} label="Critical" />
              <SevTile severity="high" count={highCount} label="High" />
              <SevTile severity="med" count={medCount} label="Medium" />
              <SevTile severity="low" count={lowCount} label="Low" />
            </div>
          </div>
        </section>

        {/* Buckets */}
        <section className="container-edge py-16">
          <div className="space-y-16">
            {scan.buckets.map((bucket) => (
              <BucketSection key={bucket.bucket} bucket={bucket} />
            ))}
          </div>

          {/* Upsell card if score is bad */}
          {scan.score < 80 && (
            <div className="mt-20 bg-ink text-bone p-10 md:p-14">
              <span className="tag text-bone/60">Lawly · Counsel tier</span>
              <h3 className="font-serif text-3xl md:text-5xl mt-4 max-w-2xl text-balance">
                Want{' '}
                <span className="pull text-oxide">paste-in</span> fixes for
                every finding?
              </h3>
              <p className="mt-4 max-w-xl text-bone/70 text-pretty">
                Counsel gives you the exact policy clauses, alt-text, banner
                config, and product-copy rewrites to clear each violation.
                Unlimited re-scans. $29/mo. Cancel anytime.
              </p>
              <a
                href="#"
                className="inline-block mt-8 bg-bone text-ink px-6 py-3 hover:bg-oxide hover:text-bone transition-colors font-medium"
              >
                Upgrade to Counsel →
              </a>
            </div>
          )}

          <div className="mt-12 flex flex-col sm:flex-row items-center justify-between gap-4 pt-8 border-t border-ink/15">
            <Link
              href="/"
              className="font-mono text-sm text-muted hover:text-oxide transition-colors"
            >
              ← New scan
            </Link>
            <div className="tag">
              Diagnostic only · Not legal advice · © Lawly
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function StatCard({
  label,
  value,
  suffix,
  accent,
}: {
  label: string;
  value: string;
  suffix?: string;
  accent?: boolean;
}) {
  return (
    <div className="border border-ink/15 bg-surface p-4">
      <div className="tag mb-2">{label}</div>
      <div
        className={`font-serif text-5xl leading-none ${
          accent ? 'text-oxide' : 'text-ink'
        }`}
      >
        {value}
        {suffix && (
          <span className="font-mono text-base text-muted ml-1">{suffix}</span>
        )}
      </div>
    </div>
  );
}

function MetaItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="tag mb-1">{label}</div>
      <div className="font-mono text-sm text-ink">{value}</div>
    </div>
  );
}

function SevTile({
  severity,
  count,
  label,
}: {
  severity: Finding['severity'];
  count: number;
  label: string;
}) {
  const empty = count === 0;
  return (
    <div className={`p-6 bg-bone ${empty ? 'opacity-50' : ''}`}>
      <div className="flex items-center gap-2 mb-2">
        <span
          className={`inline-block w-2 h-2 ${
            empty ? 'bg-ink/20' : severityDot(severity)
          }`}
        />
        <span className="tag">{label}</span>
      </div>
      <div className="font-serif text-4xl text-ink">{count}</div>
    </div>
  );
}

function severityDot(s: Finding['severity']): string {
  if (s === 'critical') return 'bg-oxide animate-pulse-slow';
  if (s === 'high') return 'bg-oxide';
  if (s === 'med') return 'bg-gold';
  return 'bg-ink/40';
}

function BucketSection({ bucket }: { bucket: BucketResult }) {
  const findings = [...bucket.findings].sort(
    (a, b) => SEV_ORDER[a.severity] - SEV_ORDER[b.severity]
  );

  return (
    <div>
      <div className="flex items-baseline justify-between mb-6 pb-4 border-b border-ink/15">
        <div className="flex items-baseline gap-4">
          <span className="tag">§</span>
          <h2 className="font-serif text-3xl md:text-4xl">
            {BUCKET_LABEL[bucket.bucket]}
          </h2>
        </div>
        <div className="flex items-center gap-3">
          <span className="tag">{bucket.passed} passed</span>
          <span className="tag text-oxide">{findings.length} issues</span>
        </div>
      </div>

      {findings.length === 0 ? (
        <div className="bg-surface-warm border border-ink/10 p-8 text-center">
          <div className="font-serif text-2xl mb-2">All clear.</div>
          <p className="text-ink-soft">
            No issues found in this bucket. Keep it that way.
          </p>
        </div>
      ) : (
        <ul className="space-y-3">
          {findings.map((f) => (
            <FindingCard key={f.id} f={f} />
          ))}
        </ul>
      )}
    </div>
  );
}

function FindingCard({ f }: { f: Finding }) {
  return (
    <li className="bg-surface border border-ink/15 p-6 md:p-8">
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="flex items-baseline gap-3 flex-wrap">
          <span
            className={`font-mono text-[10px] tracking-wider px-2 py-1 ${
              SEV_COLOR[f.severity]
            }`}
          >
            {f.severity.toUpperCase()}
          </span>
          <span className="tag">{f.code}</span>
        </div>
      </div>

      <h3 className="font-serif text-xl md:text-2xl mb-3 text-balance">
        {f.title}
      </h3>
      <p className="text-ink-soft text-pretty leading-relaxed mb-4">
        {f.detail}
      </p>

      {f.evidence && (
        <div className="bg-bone-deep/30 border-l-2 border-oxide px-4 py-3 mb-4">
          <div className="tag mb-1">Evidence</div>
          <div className="font-mono text-xs break-all">{f.evidence}</div>
        </div>
      )}

      {f.fix && (
        <div className="bg-bone-deep/30 border-l-2 border-gold px-4 py-3 mb-4">
          <div className="tag mb-1">Fix</div>
          <div className="text-sm text-ink-soft">{f.fix}</div>
        </div>
      )}

      {f.reference && (
        <div className="tag pt-2 border-t border-ink/10">
          Ref: {f.reference}
        </div>
      )}
    </li>
  );
}
