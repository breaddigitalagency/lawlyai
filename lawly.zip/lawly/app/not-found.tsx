import Link from 'next/link';
import { Nav } from '@/components/nav';
import { Footer } from '@/components/final-cta';

export default function NotFound() {
  return (
    <>
      <Nav />
      <main className="min-h-[70vh] flex items-center">
        <div className="container-edge grid grid-cols-12 gap-8 py-24">
          <div className="col-span-12 md:col-span-8">
            <span className="tag">Error · 404</span>
            <h1 className="font-serif text-display-lg mt-4 text-balance">
              That report has{' '}
              <span className="pull text-oxide">expired</span>.
            </h1>
            <p className="text-lg text-ink-soft mt-6 max-w-xl text-pretty">
              Scan reports are tied to a session and may expire after a while.
              No drama — run the audit again and you'll have a fresh report in
              thirty seconds.
            </p>
            <Link
              href="/#scan"
              className="inline-block mt-10 bg-ink text-bone px-6 py-3 hover:bg-oxide transition-colors font-medium"
            >
              Run a new scan →
            </Link>
          </div>

          <div className="col-span-12 md:col-span-4 md:text-right">
            <div className="font-mono text-xs text-muted tracking-[0.2em]">
              CASE FILE NOT FOUND
            </div>
            <div className="font-serif text-[10rem] leading-none text-oxide/20 select-none">
              404
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
