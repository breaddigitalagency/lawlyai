import { NextRequest, NextResponse } from 'next/server';
import { runScan } from '@/lib/scanner';
import { saveScan } from '@/lib/storage';

export const runtime = 'nodejs';
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const url: string = body?.url;

    if (!url || typeof url !== 'string') {
      return NextResponse.json(
        { error: 'Missing url in body' },
        { status: 400 }
      );
    }

    const result = await runScan(url);
    await saveScan(result);

    return NextResponse.json({ id: result.id });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Scan failed';
    console.error('Scan error:', err);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
