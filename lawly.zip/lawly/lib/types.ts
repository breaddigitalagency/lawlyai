export type Severity = 'critical' | 'high' | 'med' | 'low' | 'info';

export type CheckBucket = 'pages' | 'policies' | 'claims' | 'tracking';

export interface Finding {
  id: string;
  bucket: CheckBucket;
  code: string;
  severity: Severity;
  title: string;
  detail: string;
  evidence?: string;
  fix?: string;
  reference?: string;
}

export interface BucketResult {
  bucket: CheckBucket;
  status: 'ok' | 'warn' | 'fail' | 'skipped';
  findings: Finding[];
  passed: number;
  failed: number;
}

export interface ScanResult {
  id: string;
  url: string;
  hostname: string;
  startedAt: string;
  finishedAt: string;
  durationMs: number;
  grade: string; // A, B, C, D, F
  score: number; // 0-100
  totalFindings: number;
  buckets: BucketResult[];
  meta: {
    platform?: string;
    detectedJurisdiction?: string[];
    pagesFetched: number;
  };
}

export interface ScanContext {
  url: string;
  hostname: string;
  origin: string;
  homepageHtml: string;
  fetchedPages: Map<string, { url: string; status: number; html: string }>;
}
