import type { BucketResult, Finding, ScanContext, Severity } from '../types';
import { analyzePolicy, getClaude } from '../claude';

const POLICY_LABELS: Record<string, string> = {
  privacy: 'Privacy Policy',
  terms: 'Terms of Service',
  refund: 'Refund / Returns Policy',
  shipping: 'Shipping Policy',
};

// Used when no ANTHROPIC_API_KEY is set
interface KeywordCheck {
  policyKey: string;
  code: string;
  title: string;
  detail: string;
  keywords: RegExp[];
  severity: Severity;
  reference: string;
}

const KEYWORD_CHECKS: KeywordCheck[] = [
  {
    policyKey: 'privacy',
    code: 'PRV-101',
    title: 'Privacy Policy lacks GDPR lawful-basis language',
    detail:
      "Lawly couldn't find references to a lawful basis (consent, contract, legitimate interest) in your Privacy Policy. GDPR Art. 6 requires you to disclose the basis on which you process personal data.",
    keywords: [/lawful basis/i, /legitimate interest/i, /article 6/i],
    severity: 'high',
    reference: 'GDPR Art. 6 & Art. 13(1)(c)',
  },
  {
    policyKey: 'privacy',
    code: 'PRV-102',
    title: 'No CCPA "Do Not Sell or Share" disclosure',
    detail:
      'California residents have the right to opt out of the sale or sharing of their personal information. Your Privacy Policy needs to explain this right and provide a method to exercise it.',
    keywords: [/do not sell/i, /right to opt[ -]?out/i, /ccpa/i, /cpra/i],
    severity: 'high',
    reference: 'CCPA §1798.135 · CPRA',
  },
  {
    policyKey: 'privacy',
    code: 'PRV-103',
    title: 'Data subject rights (access / deletion) not enumerated',
    detail:
      "Both GDPR and the Australian Privacy Act require you to explain how customers can access, correct, or delete their data. Lawly couldn't find this language.",
    keywords: [/right to (access|delete|erasure|rectif)/i, /data subject rights/i],
    severity: 'med',
    reference: 'GDPR Art. 15-17 · AU APP 12-13',
  },
  {
    policyKey: 'refund',
    code: 'RFD-101',
    title: 'Refund Policy may contradict Australian Consumer Law',
    detail:
      'Your refund policy doesn\'t reference the consumer guarantees under the ACL. Stating "no refunds" or "all sales final" can be a per-incident penalty under s.29(1)(m) of the ACL — even if customers agreed at checkout.',
    keywords: [/consumer guarantee/i, /australian consumer law/i, /\bacl\b/i],
    severity: 'high',
    reference: 'Australian Consumer Law s.29(1)(m), s.54-59',
  },
  {
    policyKey: 'terms',
    code: 'TRM-101',
    title: 'Terms missing governing-law clause',
    detail:
      "Your Terms of Service don't specify which jurisdiction governs disputes. Without this, courts default to the customer's location — often expensive for you.",
    keywords: [/governing law/i, /jurisdiction/i, /governed by the laws/i],
    severity: 'med',
    reference: 'Standard contract enforceability',
  },
];

export async function checkPolicies(
  ctx: ScanContext,
  jurisdictions: string[] = []
): Promise<BucketResult> {
  if (ctx.fetchedPages.size === 0) {
    return { bucket: 'policies', status: 'skipped', findings: [], passed: 0, failed: 0 };
  }

  const useClaude = !!getClaude();
  return useClaude ? runClaudeAnalysis(ctx, jurisdictions) : runKeywordAnalysis(ctx);
}

async function runClaudeAnalysis(
  ctx: ScanContext,
  jurisdictions: string[]
): Promise<BucketResult> {
  const findings: Finding[] = [];

  const policyKeys = ['privacy', 'terms', 'refund', 'shipping'] as const;
  const tasks = policyKeys
    .filter((k) => ctx.fetchedPages.has(k))
    .map(async (key) => {
      const page = ctx.fetchedPages.get(key)!;
      const text = stripHtml(page.html);
      const label = POLICY_LABELS[key];

      const results = await analyzePolicy({
        policyKey: key,
        policyLabel: label,
        policyText: text,
        jurisdictions,
      });

      return results.map((r) => ({ ...r, policyKey: key, pageUrl: page.url }));
    });

  const all = (await Promise.all(tasks)).flat();

  for (const r of all) {
    findings.push({
      id: `${r.policyKey}-${r.code.toLowerCase()}`,
      bucket: 'policies',
      code: r.code,
      severity: r.severity,
      title: r.title,
      detail: r.detail,
      evidence: r.evidence,
      fix: r.fix,
      reference: r.reference,
    });
  }

  const policiesWithFindings = new Set(all.map((r) => r.policyKey));
  const passed = Math.max(0, ctx.fetchedPages.size - policiesWithFindings.size);

  const status: BucketResult['status'] =
    findings.length === 0
      ? 'ok'
      : findings.some((f) => f.severity === 'critical')
        ? 'fail'
        : 'warn';

  return {
    bucket: 'policies',
    status,
    findings,
    passed,
    failed: findings.filter((f) => f.severity !== 'low').length,
  };
}

function runKeywordAnalysis(ctx: ScanContext): BucketResult {
  const findings: Finding[] = [];
  let passed = 0;

  for (const check of KEYWORD_CHECKS) {
    const page = ctx.fetchedPages.get(check.policyKey);
    if (!page) continue;

    const text = stripHtml(page.html).toLowerCase();
    const matches = check.keywords.some((kw) => kw.test(text));

    if (!matches) {
      findings.push({
        id: check.code.toLowerCase(),
        bucket: 'policies',
        code: check.code,
        severity: check.severity,
        title: check.title,
        detail: check.detail,
        evidence: page.url,
        reference: check.reference,
      });
    } else {
      passed++;
    }
  }

  return {
    bucket: 'policies',
    status: findings.length === 0 ? 'ok' : 'warn',
    findings,
    passed,
    failed: findings.length,
  };
}

function stripHtml(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}
