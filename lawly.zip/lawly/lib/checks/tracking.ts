import * as cheerio from 'cheerio';
import type { BucketResult, Finding, ScanContext } from '../types';

interface Pixel {
  key: string;
  name: string;
  patterns: RegExp[];
  requiresConsent: boolean;
}

const PIXELS: Pixel[] = [
  {
    key: 'meta',
    name: 'Meta (Facebook) Pixel',
    patterns: [/connect\.facebook\.net\/.*fbevents/i, /fbq\s*\(\s*['"]init['"]/i],
    requiresConsent: true,
  },
  {
    key: 'ga4',
    name: 'Google Analytics 4',
    patterns: [
      /googletagmanager\.com\/gtag\/js/i,
      /gtag\s*\(\s*['"]config['"]\s*,\s*['"]G-/i,
    ],
    requiresConsent: true,
  },
  {
    key: 'gtm',
    name: 'Google Tag Manager',
    patterns: [/googletagmanager\.com\/gtm\.js/i],
    requiresConsent: true,
  },
  {
    key: 'tiktok',
    name: 'TikTok Pixel',
    patterns: [/analytics\.tiktok\.com/i, /ttq\.load/i],
    requiresConsent: true,
  },
  {
    key: 'pinterest',
    name: 'Pinterest Tag',
    patterns: [/s\.pinimg\.com\/ct\/core\.js/i, /pintrk\(/i],
    requiresConsent: true,
  },
  {
    key: 'klaviyo',
    name: 'Klaviyo',
    patterns: [/static\.klaviyo\.com\/onsite/i, /klaviyo/i],
    requiresConsent: false,
  },
];

const CONSENT_HINTS = [
  /cookie[- ]?consent/i,
  /cookiebot/i,
  /onetrust/i,
  /termly/i,
  /cookie[- ]?banner/i,
  /accept[- ]?cookies/i,
  /gdpr[- ]?banner/i,
  /klaro/i,
  /\bcookiey?es\b/i,
];

export async function checkTracking(
  ctx: ScanContext
): Promise<BucketResult> {
  const findings: Finding[] = [];
  const html = ctx.homepageHtml;
  const $ = cheerio.load(html);

  // Detect pixels
  const detected = PIXELS.filter((p) =>
    p.patterns.some((rx) => rx.test(html))
  );

  // Detect consent UI
  const text = $('body').text();
  const hasConsentUI =
    CONSENT_HINTS.some((rx) => rx.test(html) || rx.test(text)) ||
    /cookie/i.test(text) && /(accept|agree|consent)/i.test(text);

  const pixelsRequiringConsent = detected.filter((p) => p.requiresConsent);

  if (pixelsRequiringConsent.length > 0 && !hasConsentUI) {
    findings.push({
      id: 'cke-001',
      bucket: 'tracking',
      code: 'CKE-001',
      severity: 'critical',
      title: 'Tracking pixels fire with no visible cookie consent UI',
      detail: `Lawly detected ${pixelsRequiringConsent
        .map((p) => p.name)
        .join(
          ', '
        )} on your homepage but couldn't find a cookie consent banner. Under GDPR (Art. 6, Art. 7) and ePrivacy, you must obtain consent before loading non-essential tracking — this is the #1 reason for EU regulator fines on small e-commerce.`,
      evidence: `Detected: ${pixelsRequiringConsent.map((p) => p.name).join(' · ')}`,
      fix: 'Install a consent management tool (Cookiebot, Termly, Klaro, Shopify GDPR Banner). Configure it to block tracking scripts until consent is given. Re-scan with Lawly to verify.',
      reference: 'GDPR Art. 6/7 · ePrivacy Directive · UK PECR',
    });
  } else if (pixelsRequiringConsent.length > 0 && hasConsentUI) {
    // We can't tell from static HTML if the banner actually blocks scripts;
    // surface it as info.
    findings.push({
      id: 'cke-002',
      bucket: 'tracking',
      code: 'CKE-002',
      severity: 'low',
      title: 'Cookie banner detected — verify it actually blocks pre-consent firing',
      detail: `Lawly found a consent UI and tracking pixels. The banner exists, but Lawly's static scan can't confirm whether scripts are blocked until consent. Many sites show a banner but load tracking immediately — which is worse than no banner at all.`,
      evidence: `Pixels: ${pixelsRequiringConsent.map((p) => p.name).join(', ')}`,
      fix: 'In Chrome DevTools (Network tab), reload your homepage and confirm no calls to facebook.net, google-analytics, etc. happen before "Accept" is clicked.',
      reference: 'GDPR Art. 7 · ICO guidance on cookies',
    });
  }

  // Mixpanel-style platform leak
  if (/myshopify\.com/i.test(html) && !/canonical/i.test(html)) {
    findings.push({
      id: 'plt-001',
      bucket: 'tracking',
      code: 'PLT-001',
      severity: 'low',
      title: 'Shopify store leaking myshopify.com references',
      detail:
        'Your store is on Shopify but references to *.myshopify.com appear in the HTML. This usually means a missing canonical tag and can cause SEO issues plus customer confusion.',
      reference: 'Shopify SEO best practice',
    });
  }

  return {
    bucket: 'tracking',
    status: findings.length === 0 ? 'ok' : findings.some((f) => f.severity === 'critical') ? 'fail' : 'warn',
    findings,
    passed: PIXELS.length - findings.length,
    failed: findings.filter((f) => f.severity !== 'low' && f.severity !== 'info').length,
  };
}
