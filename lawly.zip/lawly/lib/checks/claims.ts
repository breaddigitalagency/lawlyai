import * as cheerio from 'cheerio';
import type { BucketResult, Finding, ScanContext } from '../types';

interface ClaimPattern {
  code: string;
  pattern: RegExp;
  title: string;
  detail: string;
  severity: Finding['severity'];
  reference: string;
}

const PATTERNS: ClaimPattern[] = [
  {
    code: 'ADS-101',
    pattern:
      /\b(clinically proven|doctor recommended|fda[- ]approved|scientifically proven|medically proven)\b/i,
    title: 'Unsubstantiated medical / clinical claim',
    detail:
      'Claims like "clinically proven" or "doctor recommended" trigger heightened FTC scrutiny and require competent, reliable scientific evidence on file. If you can\'t produce a study, this needs to come off.',
    severity: 'high',
    reference: 'FTC Health Products Compliance Guidance · ACL s.29(1)(g)',
  },
  {
    code: 'ADS-102',
    pattern: /\b(#1|number one|world['']?s best|best[- ]selling)\b/i,
    title: 'Superlative claim without substantiation',
    detail:
      'Superlatives like "#1" or "best-selling" can be deceptive without ranking data to back them up. Some jurisdictions require a basis statement (e.g. "best-selling by units in 2024").',
    severity: 'med',
    reference: 'FTC §5 · ACL s.18 misleading conduct',
  },
  {
    code: 'ADS-103',
    pattern:
      /\b(only \d+ left|hurry|selling out fast|last chance|order in the next)\b/i,
    title: 'Urgency / scarcity language present (verify it\'s real)',
    detail:
      'Fake scarcity ("only 3 left!") is a fast-growing FTC enforcement area. If the count isn\'t tied to actual inventory, this is a deceptive practice. Real timers / counts are fine — make sure they are.',
    severity: 'med',
    reference: 'FTC §5 · ROSCA · ACL s.18',
  },
  {
    code: 'ADS-104',
    pattern: /\b(money[- ]back guarantee|100% satisfaction|risk[- ]free)\b/i,
    title: '"Risk-free" or "money-back guarantee" language',
    detail:
      'These phrases bind you to refund anyone who asks, no exceptions. If your refund policy contradicts this (e.g. excludes opened items), the FTC and ACL treat it as deceptive.',
    severity: 'med',
    reference: 'FTC §5 · Magnuson-Moss Warranty Act · ACL s.29',
  },
  {
    code: 'ADS-105',
    pattern: /\b(was \$|\$[\d,]+\.\d{2}\s*<|strikethrough|compare at \$)/i,
    title: 'Strikethrough pricing present — confirm real reference price',
    detail:
      'Showing "Was $X, now $Y" requires the higher price to be a genuine recent sale price (typically 30 days under ACL guidance). FTC and ACCC both bring cases on fake reference pricing.',
    severity: 'med',
    reference: 'ACCC reference pricing guidance · FTC Guides Against Deceptive Pricing',
  },
];

export async function checkClaims(
  ctx: ScanContext
): Promise<BucketResult> {
  const findings: Finding[] = [];
  let passed = 0;

  // V1 scans the homepage HTML only; V2 will sample product pages too
  const $ = cheerio.load(ctx.homepageHtml);

  // Extract visible text only
  $('script, style, noscript').remove();
  const text = $('body').text().replace(/\s+/g, ' ').trim();
  const html = ctx.homepageHtml;

  for (const p of PATTERNS) {
    const match = text.match(p.pattern) || html.match(p.pattern);
    if (match) {
      const snippet = extractSnippet(text, match.index ?? 0);
      findings.push({
        id: p.code.toLowerCase(),
        bucket: 'claims',
        code: p.code,
        severity: p.severity,
        title: p.title,
        detail: p.detail,
        evidence: snippet ? `"${snippet}"` : undefined,
        reference: p.reference,
      });
    } else {
      passed++;
    }
  }

  return {
    bucket: 'claims',
    status: findings.length === 0 ? 'ok' : 'warn',
    findings,
    passed,
    failed: findings.length,
  };
}

function extractSnippet(text: string, idx: number, len = 80): string {
  const start = Math.max(0, idx - 20);
  const end = Math.min(text.length, idx + len);
  return text.slice(start, end).trim();
}
