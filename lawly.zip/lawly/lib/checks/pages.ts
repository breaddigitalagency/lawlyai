import * as cheerio from 'cheerio';
import { fetchMany } from '../fetch';
import type { BucketResult, Finding, ScanContext } from '../types';

interface PolicyTarget {
  key: string;
  label: string;
  // Match patterns in link text / href
  linkPatterns: RegExp[];
  // Common URL paths to try if link discovery fails
  urlGuesses: string[];
  severity: 'critical' | 'high' | 'med';
  reference: string;
}

const TARGETS: PolicyTarget[] = [
  {
    key: 'privacy',
    label: 'Privacy Policy',
    linkPatterns: [/privacy[ -]?policy/i, /privacy[ -]?notice/i, /^privacy$/i],
    urlGuesses: [
      '/policies/privacy-policy',
      '/pages/privacy-policy',
      '/pages/privacy',
      '/privacy',
      '/privacy-policy',
      '/legal/privacy',
    ],
    severity: 'critical',
    reference: 'GDPR Art. 13 · CCPA §1798.130 · AU Privacy Act APP 1',
  },
  {
    key: 'terms',
    label: 'Terms of Service',
    linkPatterns: [
      /terms[ -]?(of[ -])?(service|use)/i,
      /terms[ -]?and[ -]?conditions/i,
      /^terms$/i,
      /\btos\b/i,
    ],
    urlGuesses: [
      '/policies/terms-of-service',
      '/pages/terms-of-service',
      '/pages/terms',
      '/terms',
      '/terms-of-service',
      '/legal/terms',
    ],
    severity: 'high',
    reference: 'Contract enforceability · platform requirement',
  },
  {
    key: 'refund',
    label: 'Refund / Returns Policy',
    linkPatterns: [
      /refund[ -]?policy/i,
      /return[ -]?policy/i,
      /^returns?$/i,
      /^refunds?$/i,
    ],
    urlGuesses: [
      '/policies/refund-policy',
      '/policies/return-policy',
      '/pages/refund-policy',
      '/pages/returns',
      '/refund-policy',
      '/returns',
    ],
    severity: 'high',
    reference: 'FTC Mail Order Rule · AU Consumer Law s.54-59',
  },
  {
    key: 'shipping',
    label: 'Shipping Policy',
    linkPatterns: [/shipping[ -]?policy/i, /^shipping$/i, /delivery[ -]?policy/i],
    urlGuesses: [
      '/policies/shipping-policy',
      '/pages/shipping-policy',
      '/pages/shipping',
      '/shipping',
      '/shipping-policy',
    ],
    severity: 'med',
    reference: 'FTC Mail Order Rule · ACL pre-contract disclosure',
  },
  {
    key: 'contact',
    label: 'Contact / About disclosure',
    linkPatterns: [/^contact( us)?$/i, /^about( us)?$/i, /get in touch/i],
    urlGuesses: [
      '/pages/contact',
      '/pages/contact-us',
      '/pages/about',
      '/contact',
      '/about',
    ],
    severity: 'med',
    reference: 'EU e-Commerce Directive · ACL business identification',
  },
];

export async function checkMissingPages(
  ctx: ScanContext
): Promise<BucketResult> {
  const findings: Finding[] = [];
  const $ = cheerio.load(ctx.homepageHtml);

  // Step 1: collect all links from the homepage
  const links: { href: string; text: string }[] = [];
  $('a[href]').each((_, el) => {
    const href = $(el).attr('href') || '';
    const text = $(el).text().trim();
    if (href) links.push({ href, text });
  });

  // For each policy type, check link discovery first, then URL guesses
  let passed = 0;

  for (const target of TARGETS) {
    const matched = links.find(({ href, text }) =>
      target.linkPatterns.some(
        (p) => p.test(text) || p.test(href.toLowerCase())
      )
    );

    if (matched) {
      // We found a link. Verify it actually resolves to a real page.
      const resolved = resolveUrl(matched.href, ctx.origin);
      if (resolved) {
        const pages = await fetchMany([resolved], 1, 5000);
        const page = pages[0];
        if (page.ok && page.html.length > 800) {
          ctx.fetchedPages.set(target.key, {
            url: page.finalUrl,
            status: page.status,
            html: page.html,
          });
          passed++;
          continue;
        }
        if (page.ok && page.html.length <= 800) {
          findings.push({
            id: `${target.key}-stub`,
            bucket: 'pages',
            code: `${target.key.toUpperCase()}-002`,
            severity: 'high',
            title: `${target.label} appears to be a stub`,
            detail: `Lawly found a link to "${target.label}" but the page is shorter than 800 characters — likely a placeholder or default theme content.`,
            evidence: resolved,
            fix: `Replace the stub with a full policy that addresses required clauses (see Policy Gaps audit).`,
            reference: target.reference,
          });
          continue;
        }
      }
    }

    // No link found, or link broken. Try URL guesses.
    const guesses = target.urlGuesses.map((p) => `${ctx.origin}${p}`);
    const results = await fetchMany(guesses, 5, 5000);
    const hit = results.find((r) => r.ok && r.html.length > 800);

    if (hit) {
      ctx.fetchedPages.set(target.key, {
        url: hit.finalUrl,
        status: hit.status,
        html: hit.html,
      });
      passed++;
      findings.push({
        id: `${target.key}-orphan`,
        bucket: 'pages',
        code: `${target.key.toUpperCase()}-003`,
        severity: 'low',
        title: `${target.label} exists but isn't linked from the homepage`,
        detail: `The page exists at ${stripOrigin(
          hit.finalUrl,
          ctx.origin
        )} but isn't reachable from the homepage navigation or footer. Customers (and regulators) can't find what they can't see.`,
        evidence: hit.finalUrl,
        fix: `Add a footer link to "${target.label}" pointing to ${stripOrigin(
          hit.finalUrl,
          ctx.origin
        )}.`,
        reference: target.reference,
      });
      continue;
    }

    findings.push({
      id: `${target.key}-missing`,
      bucket: 'pages',
      code: `${target.key.toUpperCase()}-001`,
      severity: target.severity,
      title: `${target.label} is missing`,
      detail: `Lawly couldn't find a ${target.label.toLowerCase()} on this store. Most consumer-protection frameworks require it to be available before purchase.`,
      fix: `Publish a ${target.label.toLowerCase()} and link it from the footer of every page. Use Lawly's Counsel tier to generate a draft tailored to your jurisdiction.`,
      reference: target.reference,
    });
  }

  const status: BucketResult['status'] =
    findings.length === 0 ? 'ok' : findings.some((f) => f.severity === 'critical') ? 'fail' : 'warn';

  return {
    bucket: 'pages',
    status,
    findings,
    passed,
    failed: findings.filter((f) => f.severity !== 'low' && f.severity !== 'info').length,
  };
}

function resolveUrl(href: string, origin: string): string | null {
  try {
    if (href.startsWith('mailto:') || href.startsWith('tel:')) return null;
    return new URL(href, origin).toString();
  } catch {
    return null;
  }
}

function stripOrigin(url: string, origin: string): string {
  return url.startsWith(origin) ? url.slice(origin.length) || '/' : url;
}
