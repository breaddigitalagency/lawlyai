import Anthropic from '@anthropic-ai/sdk';

let client: Anthropic | null = null;

export function getClaude(): Anthropic | null {
  if (client) return client;
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return null;
  client = new Anthropic({ apiKey: key });
  return client;
}

export interface ClaudeAnalysisRequest {
  policyKey: string;
  policyLabel: string;
  policyText: string;
  jurisdictions: string[];
}

export interface ClaudePolicyFinding {
  code: string;
  title: string;
  detail: string;
  severity: 'critical' | 'high' | 'med' | 'low';
  reference: string;
  fix?: string;
  evidence?: string;
}

const SYSTEM_PROMPT = `You are a legal-compliance reviewer evaluating e-commerce store policies (Privacy Policy, Terms of Service, Refund Policy, Shipping Policy).

You audit policies against the FTC, CCPA/CPRA, GDPR, UK GDPR, Canadian PIPEDA/CASL, and the Australian Consumer Law / Privacy Act.

For the policy text the user provides, return a JSON array of findings — only the things that are MISSING or PROBLEMATIC. Do NOT list what's correct.

Each finding must have:
- code: a short stable identifier like "PRV-201" (PRV/TRM/RFD/SHP prefix + 3-digit number)
- title: one sentence describing the gap, written like an editor would
- detail: 2-3 sentences explaining what's missing and why it matters legally
- severity: "critical" | "high" | "med" | "low"
- reference: which law/regulation/section this maps to
- fix: a short concrete suggestion (1 sentence)
- evidence: a short quote from the policy text that demonstrates the gap, OR null if the issue is omission

Severity guide:
- critical = clear violation that exposes the merchant to immediate regulator action or class actions
- high = standard requirement that's missing and routinely enforced
- med = best practice that's commonly required but rarely enforced
- low = polish / clarity issue

Calibrate to the declared jurisdictions. If the store ships to AU, weight ACL findings higher. If EU customers are likely, weight GDPR.

Be skeptical but not pedantic. Aim for 3-8 findings per policy — surface what actually matters.

Respond ONLY with a JSON array, no preamble, no markdown fences. If the policy looks clean, return [].`;

export async function analyzePolicy(
  req: ClaudeAnalysisRequest
): Promise<ClaudePolicyFinding[]> {
  const claude = getClaude();
  if (!claude) return [];

  // Cap policy text — most policies are < 30k chars, but some are huge
  const text = req.policyText.slice(0, 50000);

  const userMessage = `Policy type: ${req.policyLabel}
Declared jurisdictions: ${req.jurisdictions.join(', ') || 'unknown'}

---
POLICY TEXT:
${text}
---

Return the JSON array of findings now.`;

  try {
    const response = await claude.messages.create({
      model: 'claude-opus-4-7',
      max_tokens: 4000,
      system: SYSTEM_PROMPT,
      messages: [{ role: 'user', content: userMessage }],
    });

    const block = response.content.find((b) => b.type === 'text');
    if (!block || block.type !== 'text') return [];

    const raw = block.text.trim();
    // Strip any accidental code fences
    const clean = raw.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim();

    const parsed = JSON.parse(clean);
    if (!Array.isArray(parsed)) return [];

    // Defensive validation
    return parsed
      .filter(
        (f) =>
          typeof f === 'object' &&
          typeof f.code === 'string' &&
          typeof f.title === 'string' &&
          typeof f.detail === 'string' &&
          ['critical', 'high', 'med', 'low'].includes(f.severity)
      )
      .map((f) => ({
        code: f.code,
        title: f.title,
        detail: f.detail,
        severity: f.severity,
        reference: f.reference || 'General compliance',
        fix: f.fix || undefined,
        evidence: f.evidence || undefined,
      }));
  } catch (err) {
    console.error(`Claude policy analysis failed for ${req.policyKey}:`, err);
    return [];
  }
}
