import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { ScanResult } from './types';

// Two-tier storage:
// 1. If Supabase env vars are set, persist to a `scans` table.
// 2. Otherwise, fall back to an in-memory Map (dev only — won't survive
//    serverless cold starts in production).

declare global {
  // eslint-disable-next-line no-var
  var __lawly_scans: Map<string, ScanResult> | undefined;
}

const memoryStore = global.__lawly_scans ?? new Map<string, ScanResult>();
if (!global.__lawly_scans) global.__lawly_scans = memoryStore;

let supabase: SupabaseClient | null = null;

function getSupabase(): SupabaseClient | null {
  if (supabase) return supabase;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key =
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  supabase = createClient(url, key, {
    auth: { persistSession: false },
  });
  return supabase;
}

export async function saveScan(result: ScanResult): Promise<void> {
  const sb = getSupabase();

  if (sb) {
    const { error } = await sb.from('scans').insert({
      id: result.id,
      hostname: result.hostname,
      url: result.url,
      grade: result.grade,
      score: result.score,
      total_findings: result.totalFindings,
      duration_ms: result.durationMs,
      payload: result,
      created_at: result.finishedAt,
    });
    if (error) {
      console.error('Supabase save failed, falling back to memory:', error.message);
      memoryStore.set(result.id, result);
    }
    return;
  }

  memoryStore.set(result.id, result);
}

export async function getScan(id: string): Promise<ScanResult | null> {
  const sb = getSupabase();

  if (sb) {
    const { data, error } = await sb
      .from('scans')
      .select('payload')
      .eq('id', id)
      .single();
    if (error || !data) {
      // Try memory as a last resort (dev workflow)
      return memoryStore.get(id) ?? null;
    }
    return data.payload as ScanResult;
  }

  return memoryStore.get(id) ?? null;
}
