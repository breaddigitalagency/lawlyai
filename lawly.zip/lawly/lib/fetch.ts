const UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

export interface FetchResult {
  url: string;
  finalUrl: string;
  status: number;
  ok: boolean;
  html: string;
  contentType: string;
}

export async function fetchPage(
  url: string,
  timeoutMs = 8000
): Promise<FetchResult> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': UA,
        Accept: 'text/html,application/xhtml+xml',
        'Accept-Language': 'en-AU,en-US;q=0.9,en;q=0.8',
      },
      redirect: 'follow',
      signal: controller.signal,
    });

    const contentType = res.headers.get('content-type') || '';
    const html = contentType.includes('text/html') ? await res.text() : '';

    return {
      url,
      finalUrl: res.url,
      status: res.status,
      ok: res.ok,
      html,
      contentType,
    };
  } catch (err) {
    return {
      url,
      finalUrl: url,
      status: 0,
      ok: false,
      html: '',
      contentType: '',
    };
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchMany(
  urls: string[],
  concurrency = 5,
  timeoutMs = 6000
): Promise<FetchResult[]> {
  const results: FetchResult[] = [];
  const queue = [...urls];

  async function worker() {
    while (queue.length) {
      const url = queue.shift();
      if (!url) break;
      results.push(await fetchPage(url, timeoutMs));
    }
  }

  await Promise.all(
    Array.from({ length: Math.min(concurrency, urls.length) }, worker)
  );

  return results;
}
