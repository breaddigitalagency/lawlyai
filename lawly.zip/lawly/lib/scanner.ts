import { nanoid } from 'nanoid';
import { fetchPage } from './fetch';
import { checkMissingPages } from './checks/pages';
import { checkPolicies } from './checks/policies';
import { checkClaims } from './checks/claims';
import { checkTracking } from './checks/tracking';
import type { BucketResult, ScanContext, ScanResult } from './types';

export async function runScan(rawUrl: string): Promise<ScanResult> {
  const started = Date.now();
  const id = nanoid(10);

  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error('Invalid URL');
  }

  if (!['http:', 'https:'].includes(url.protocol)) {
    throw new Error('URL must be http or https');
  }

  const home = await fetchPage(url.toString(), 10000);
  if (!home.ok || !home.html) {
    throw new Error(
      `Couldn't reach ${url.hostname} (status ${home.status}). If it's password-protected or geo-blocked, we can't scan it yet.`
    );
  }

  const platform = detectPlatform(home.html);
  const jurisdictions = detectJurisdiction(home.html, url.hostname);

  const ctx: ScanContext = {
    url: home.finalUrl,
    hostname: url.hostname,
    origin: url.origin,
    homepageHtml: home.html,
    fetchedPages: new Map(),
  };

  // Pages check first — it populates fetchedPages used by policies check
  const pagesResult = await checkMissingPages(ctx);

  // Run the other three in parallel
  const [policiesResult, claimsResult, trackingResult] = await Promise.all([
    checkPolicies(ctx, jurisdictions),
    checkClaims(ctx),
    checkTracking(ctx),
  ]);

  const buckets: BucketResult[] = [
    pagesResult,
    policiesResult,
    claimsResult,
    trackingResult,
  ];

  const totalFindings = buckets.reduce((n, b) => n + b.findings.length, 0);
  const { grade, score } = computeGrade(buckets);

  const finished = Date.now();

  return {
    id,
    url: home.finalUrl,
    hostname: url.hostname,
    startedAt: new Date(started).toISOString(),
    finishedAt: new Date(finished).toISOString(),
    durationMs: finished - started,
    grade,
    score,
    totalFindings,
    buckets,
    meta: {
      platform,
      detectedJurisdiction: jurisdictions,
      pagesFetched: 1 + ctx.fetchedPages.size,
    },
  };
}

function computeGrade(buckets: BucketResult[]): { grade: string; score: number } {
  const weights = { critical: 25, high: 10, med: 4, low: 1, info: 0 };
  let penalty = 0;
  for (const b of buckets) {
    for (const f of b.findings) {
      penalty += weights[f.severity] ?? 0;
    }
  }
  const score = Math.max(0, 100 - penalty);

  let grade: string;
  if (score >= 90) grade = 'A';
  else if (score >= 80) grade = 'B';
  else if (score >= 70) grade = 'C';
  else if (score >= 55) grade = 'D';
  else if (score >= 40) grade = 'D−';
  else grade = 'F';

  return { grade, score };
}

function detectPlatform(html: string): string | undefined {
  if (/cdn\.shopify\.com|myshopify/i.test(html)) return 'Shopify';
  if (/wp-content|wordpress/i.test(html)) return 'WordPress / WooCommerce';
  if (/squarespace/i.test(html)) return 'Squarespace';
  if (/wix\.com/i.test(html)) return 'Wix';
  if (/bigcommerce/i.test(html)) return 'BigCommerce';
  if (/webflow/i.test(html)) return 'Webflow';
  return undefined;
}

function detectJurisdiction(html: string, hostname: string): string[] {
  const j: string[] = [];
  if (hostname.endsWith('.au') || /AUD|Australia/i.test(html)) j.push('AU');
  if (hostname.endsWith('.uk') || /GBP|United Kingdom/i.test(html)) j.push('UK');
  if (hostname.endsWith('.ca') || /CAD\b/i.test(html)) j.push('CA');
  if (hostname.endsWith('.eu') || /€|EUR\b/i.test(html)) j.push('EU');
  if (/USD|United States/i.test(html)) j.push('US');
  return j.length ? j : ['Unknown'];
}
