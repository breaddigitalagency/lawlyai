# Lawly

**The legal audit your store hopes you never run.**

A forensic compliance scanner for e-commerce stores. Paste a URL, get a
graded report on FTC violations, GDPR gaps, missing policies, ad-claim
risks, and tracking-consent issues — in about 30 seconds.

---

## Stack

- **Next.js 15** (App Router, React 19)
- **TypeScript** end-to-end
- **Tailwind CSS** with custom design tokens (bone / ink / oxide palette)
- **Cheerio** for HTML parsing
- **Anthropic Claude SDK** for AI-powered policy clause analysis
- **Supabase** for scan persistence (with in-memory fallback for dev)
- **Vercel** for hosting

No Playwright — keeps it inside Vercel free-tier serverless limits.

---

## Project structure

```
lawly/
├── app/
│   ├── api/scan/route.ts        # POST /api/scan
│   ├── scan/[id]/page.tsx       # Report page (SSR)
│   ├── not-found.tsx            # 404 for missing reports
│   ├── page.tsx                 # Landing page
│   ├── layout.tsx
│   └── globals.css
├── components/
│   ├── nav.tsx
│   ├── hero.tsx                 # Hero + report-preview mockup
│   ├── scan-form.tsx            # URL input (client component)
│   ├── marquee.tsx              # Forensic ticker
│   ├── checks-grid.tsx          # 4-bucket overview
│   ├── how-it-works.tsx
│   ├── pricing.tsx
│   ├── faq.tsx
│   └── final-cta.tsx            # Final CTA + Footer
├── lib/
│   ├── scanner.ts               # Orchestrator
│   ├── claude.ts                # Anthropic SDK wrapper + system prompt
│   ├── fetch.ts                 # HTTP helpers (timeout, concurrency)
│   ├── storage.ts               # Supabase + in-memory store
│   ├── types.ts                 # Shared types
│   └── checks/
│       ├── pages.ts             # Missing required pages
│       ├── policies.ts          # Claude analysis (fallback: keyword)
│       ├── claims.ts            # Risky ad copy patterns
│       └── tracking.ts          # Pixels + consent UI detection
├── supabase/
│   └── migrations/
│       └── 0001_init.sql        # Run this in Supabase SQL Editor
├── scripts/
│   └── test-scan.ts             # Local smoke test
└── ...config files
```

---

## Deploy to Vercel

### Step 1 — Push to GitHub

```bash
cd lawly
git init
git add .
git commit -m "Lawly v1"
gh repo create lawly --private --source=. --push
```

### Step 2 — Create the Vercel project

1. <https://vercel.com/new>
2. Import the GitHub repo
3. Framework preset: **Next.js** (auto-detected)
4. Don't set env vars yet — deploy first, see the page load
5. Click **Deploy**

### Step 3 — Add the domain

In Vercel → your project → **Settings → Domains** → add `lawlyaichecker.com`
and `www.lawlyaichecker.com`. Vercel will give you the DNS records to set
at your registrar.

### Step 4 — Wire up Supabase (so scans persist)

In Supabase:

1. Create a new project (or use an existing one)
2. **SQL Editor** → paste the contents of `supabase/migrations/0001_init.sql`
   → Run
3. **Project Settings → API**, grab the project URL, anon key, and
   service-role key

In Vercel → **Settings → Environment Variables**, add:

```
NEXT_PUBLIC_SUPABASE_URL          https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY     eyJ...
SUPABASE_SERVICE_ROLE_KEY         eyJ...
```

Redeploy. Scans now persist.

### Step 5 — Wire up Claude (Claude-powered policy analysis)

The keyword-based policy check works without an API key, but the Claude
analysis is dramatically better. In Vercel → env vars, add:

```
ANTHROPIC_API_KEY                 sk-ant-...
```

Redeploy. The policies bucket now uses Claude.

---

## Local dev

```bash
npm install
cp .env.example .env.local
# Fill in env vars (optional — works without them)
npm run dev
```

Open <http://localhost:3000>. Paste a real store URL into the hero input.

To smoke-test the scanner directly without the UI:

```bash
npx tsx scripts/test-scan.ts https://yourstore.com
```

---

## How the scanner works

`runScan(url)` in `lib/scanner.ts`:

1. **Fetch homepage** (10s timeout, browser-shaped User-Agent)
2. **Detect platform + jurisdiction** from HTML signals
3. **Pages check** — looks for required policy pages via link discovery
   and URL guessing. Populates `ctx.fetchedPages` with full HTML of each
   policy found.
4. **In parallel:**
   - **Policies check** — sends each policy's text to Claude (or
     keyword-matches if no API key). Returns structured findings.
   - **Claims check** — scans homepage for risky ad copy patterns
     (unsubstantiated health claims, fake urgency, etc.)
   - **Tracking check** — detects pixels (Meta, GA4, TikTok, etc.) and
     whether a consent banner is present.
5. **Compute grade** — weighted penalty (critical=25, high=10, med=4, low=1).
   Score is 100 minus penalty.

Total time on a typical Shopify store: 8–25 seconds depending on how
many policies need fetching and whether Claude is enabled.

---

## V1 vs the roadmap

### Live in v1 (this build)

- ✅ Landing page (editorial design)
- ✅ Working scan → report pipeline
- ✅ **Missing pages** check (5 required policies)
- ✅ **Policy gaps** check (Claude when API key set, keyword fallback)
- ✅ **Ad & copy risk** check (5 pattern categories)
- ✅ **Tracking & consent** check (6 pixel detectors + consent heuristic)
- ✅ Compliance grade A → F with weighted scoring
- ✅ Severity ordering, evidence snippets, fix suggestions
- ✅ Jurisdiction + platform detection
- ✅ Supabase persistence with in-memory fallback
- ✅ Shareable public report URLs (Reddit-ready)

### Wire up next

- ⏳ **Auth + user accounts** — Supabase Auth, gate Counsel tier features
- ⏳ **Stripe billing** — Counsel ($29/mo), Firm ($149/mo)
- ⏳ **Email alerts** — scheduled re-scans, notify on new findings
- ⏳ **Product page sampling** — currently only homepage is scanned for
  claims; v2 should crawl 3–5 product pages
- ⏳ **PDF export** — let users download the report
- ⏳ **Public "wall of shame"** — anonymized aggregate stats (Reddit fuel)
- ⏳ **Authenticated scans** — log into Shopify admin to scan checkout flow
- ⏳ **Bot-protected stores** — paid scraping API fallback for Cloudflare /
  PerimeterX-protected stores (ScrapingBee, Bright Data)

---

## Reddit go-to-market playbook

Reddit doesn't tolerate self-promotion. The play is **content that's
genuinely useful**, with the tool linked in your profile / bio, never the
post body. Goal: become known as "the legal scan person," not "the
person spamming a tool."

### Subreddits to seed (ranked by ROI)

| Sub | Size | Why it works | Angle |
|-----|------|--------------|-------|
| r/shopify | 285k | Operators, exact ICP | Audit findings |
| r/ecommerce | 380k | Broader but ICP | Compliance breakdowns |
| r/EntrepreneurRideAlong | 500k | Loves build-in-public | Building Lawly story |
| r/SideProject | 250k | Indie-friendly | Launch post (works once) |
| r/dropship | 240k | Highest risk, biggest pain | "I scanned 50 dropship stores" |
| r/SaaS | 320k | Founders building B2B | Behind the scenes |
| r/SmallBusiness | 2M | US small biz | FTC compliance angle |
| r/AusFinance | 750k | AU market, you're local | ACL-specific content |
| r/AustralianBusiness | 80k | AU operators | ACL audits |

### The 4 post formats that work

**1. "I audited 50 stores in [niche]" — DATA POST**
Run Lawly against the top 50 Shopify stores in skincare / supplements /
streetwear. Anonymize them. Post the aggregate: "82% of these stores fail
GDPR. 64% have unsubstantiated claims. Here's the breakdown by category."
Lawly link in your profile bio only.

**2. "I got my own store audited" — SELF-DEPRECATING POST**
Run Lawly on Comic Central Supply. Post screenshots of your own findings.
"Here's what I'm fixing this week." Karma magnet, drives curiosity.

**3. "FTC just fined someone for X" — REACTIVE POST**
Hook to real news. "FTC just fined [company] $5M for fake scarcity timers.
Here's a 5-minute checklist to audit your own store." Drop tool in a
comment if asked.

**4. "ELI5 these laws actually matter" — REFERENCE POST**
Translate FTC / GDPR / ACL into plain English. Long-form, high-effort.
Becomes a reference post people link back to for months.

### What NOT to do

- ❌ "Hey r/shopify, just launched my tool"
- ❌ Posting the same content in 10 subs in one day
- ❌ Replying to every thread with "btw I built [tool]"

### Cadence

- 1 high-effort post per week, max
- Comment-first for 2 weeks before posting — build account history
- Track which posts convert via UTM params on the bio link

### Adjacent free channels

- **Twitter/X** — build-in-public, weekly audit screenshots
- **Indie Hackers** — launch post + weekly milestones
- **Product Hunt** — save for v1.5 (one shot)
- **Hacker News** — only with a content piece, never a "launch"

---

## Design system

The aesthetic is deliberate: **editorial legal-forensic.** Not SaaS, not
streetwear, not "modern startup." Think Bloomberg article meets a luxury
law firm's diagnostic report.

- **Display:** Instrument Serif (italic = "the pull" for emphasis)
- **Body:** IBM Plex Sans
- **Data:** IBM Plex Mono
- **Bone** (#F5F1E8) is the canvas
- **Ink** (#1A1611) is text
- **Oxide** (#C73E1D) is danger only — used sparingly
- **Gold** (#B8935A) is muted authority for "passed"
- Paper grain overlay on body (subtle, don't crank it)
- Asymmetric 12-col grids, generous negative space
- No purple gradients. No Inter. No stock SaaS components.

---

## License

Proprietary © Lawly. All rights reserved.
