const tiers = [
  {
    name: 'Scout',
    price: '$0',
    cadence: 'one-time',
    blurb: 'See if your store has obvious problems. Most do.',
    cta: 'Run free scan',
    href: '#hero-form',
    features: [
      '1 free scan',
      'Top 5 findings revealed',
      'Compliance grade',
      'PDF export',
    ],
    highlight: false,
  },
  {
    name: 'Counsel',
    price: '$29',
    cadence: '/ month',
    blurb: 'For founders who\'d rather not be the test case.',
    cta: 'Start with Counsel',
    href: '#hero-form',
    features: [
      'Unlimited scans',
      'Every finding, with code references',
      'Copy-paste fix suggestions',
      'Re-scan on policy change',
      'Email alerts on new violations',
      'Multi-store dashboard',
    ],
    highlight: true,
  },
  {
    name: 'Firm',
    price: '$149',
    cadence: '/ month',
    blurb: 'For agencies and operators with 5+ stores.',
    cta: 'Talk to us',
    href: 'mailto:hello@lawlyaichecker.com',
    features: [
      'Everything in Counsel',
      'Up to 25 stores',
      'White-label PDF reports',
      'API access',
      'Priority support',
    ],
    highlight: false,
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="py-24 md:py-32 border-t border-ink/15">
      <div className="container-edge">
        <div className="grid grid-cols-12 gap-8 mb-16">
          <div className="col-span-12 md:col-span-7">
            <span className="tag">§ 04 · Retainer</span>
            <h2 className="font-serif text-display-lg mt-4 text-balance">
              Cheaper than{' '}
              <span className="pull text-oxide">one hour</span> with a lawyer.
            </h2>
          </div>
          <div className="col-span-12 md:col-span-5 flex items-end">
            <p className="text-ink-soft text-pretty">
              We're not a law firm. We're a forensic tool that catches what a
              lawyer would charge you $300/hr to find. Cancel anytime.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-ink/15">
          {tiers.map((tier) => (
            <div
              key={tier.name}
              className={`relative p-8 md:p-10 flex flex-col ${
                tier.highlight ? 'bg-ink text-bone' : 'bg-bone'
              }`}
            >
              {tier.highlight && (
                <div className="absolute -top-3 left-10">
                  <span className="bg-oxide text-bone tag px-2 py-1">
                    Most picked
                  </span>
                </div>
              )}

              <div className="flex items-baseline justify-between mb-2">
                <h3 className="font-serif text-3xl">{tier.name}</h3>
                <span
                  className={`tag ${
                    tier.highlight ? 'text-bone/60' : 'text-muted'
                  }`}
                >
                  tier
                </span>
              </div>

              <p
                className={`mb-6 ${
                  tier.highlight ? 'text-bone/70' : 'text-ink-soft'
                }`}
              >
                {tier.blurb}
              </p>

              <div className="mb-8">
                <span className="font-serif text-6xl">{tier.price}</span>
                <span
                  className={`ml-2 font-mono text-sm ${
                    tier.highlight ? 'text-bone/60' : 'text-muted'
                  }`}
                >
                  {tier.cadence}
                </span>
              </div>

              <ul className="space-y-3 mb-10 flex-1">
                {tier.features.map((f) => (
                  <li
                    key={f}
                    className={`flex items-baseline gap-3 text-sm ${
                      tier.highlight ? 'text-bone/90' : 'text-ink-soft'
                    }`}
                  >
                    <span
                      className={
                        tier.highlight ? 'text-oxide' : 'text-oxide font-mono'
                      }
                    >
                      ✓
                    </span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <a
                href={tier.href}
                className={`block text-center py-3 transition-colors font-medium tracking-wide ${
                  tier.highlight
                    ? 'bg-bone text-ink hover:bg-oxide hover:text-bone'
                    : 'bg-ink text-bone hover:bg-oxide'
                }`}
              >
                {tier.cta} →
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
