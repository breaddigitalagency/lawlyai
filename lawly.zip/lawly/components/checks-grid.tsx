const checks = [
  {
    n: '01',
    name: 'Missing Pages',
    status: 'live',
    desc: 'We crawl your footer, nav, and policy URLs to find what isn\'t there.',
    items: [
      'Privacy Policy',
      'Terms of Service',
      'Refund / Returns',
      'Shipping Policy',
      'Contact disclosure',
    ],
  },
  {
    n: '02',
    name: 'Policy Gaps',
    status: 'live',
    desc: 'AI reads the policies you do have and finds the clauses you don\'t.',
    items: [
      'GDPR lawful basis & data rights',
      'CCPA opt-out language',
      'Australian Consumer Law guarantees',
      'Cookie & tracking disclosure',
      'Auto-renewal terms',
    ],
  },
  {
    n: '03',
    name: 'Ad & Copy Risk',
    status: 'beta',
    desc: 'Product pages and landers, scanned for the claims that draw lawsuits.',
    items: [
      'Unsubstantiated health claims',
      'Fake scarcity / urgency timers',
      'Doctored review badges',
      'Disclosed influencer relationships',
      'Comparative price strikethrough',
    ],
  },
  {
    n: '04',
    name: 'Tracking & Consent',
    status: 'beta',
    desc: 'Pixels, cookies, and the consent banner that probably isn\'t working.',
    items: [
      'Meta Pixel pre-consent firing',
      'GA4 IP-anonymization',
      'TikTok pixel disclosure',
      'Klaviyo / email consent',
      'Cookie banner geo-targeting',
    ],
  },
];

export function ChecksGrid() {
  return (
    <section id="checks" className="py-24 md:py-32">
      <div className="container-edge">
        {/* Section header */}
        <div className="grid grid-cols-12 gap-8 mb-16">
          <div className="col-span-12 md:col-span-5">
            <span className="tag">§ 02 · The audit</span>
            <h2 className="font-serif text-display-lg mt-4 text-balance">
              Four buckets. <span className="pull text-oxide">Forty-plus</span>{' '}
              checks.
            </h2>
          </div>
          <div className="col-span-12 md:col-span-6 md:col-start-7 flex items-end">
            <p className="text-lg text-ink-soft text-pretty max-w-md">
              Most legal tools sell you a policy generator and call it
              compliance. Lawly does the opposite — it reads what you already
              shipped and tells you where it leaks.
            </p>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 border-t border-l border-ink/15">
          {checks.map((c) => (
            <article
              key={c.n}
              className="group relative border-b border-r border-ink/15 p-8 md:p-10 hover:bg-surface-warm transition-colors"
            >
              {/* Top row */}
              <div className="flex items-start justify-between mb-8">
                <span className="font-mono text-xs tracking-[0.2em] text-muted">
                  {c.n}
                </span>
                <span
                  className={`tag px-2 py-0.5 ${
                    c.status === 'live'
                      ? 'bg-ink text-bone'
                      : 'border border-ink/30 text-ink-soft'
                  }`}
                >
                  {c.status}
                </span>
              </div>

              <h3 className="font-serif text-3xl md:text-4xl mb-4 leading-tight">
                {c.name}
              </h3>

              <p className="text-ink-soft mb-6 max-w-sm">{c.desc}</p>

              <ul className="space-y-2">
                {c.items.map((item) => (
                  <li
                    key={item}
                    className="flex items-baseline gap-3 text-sm text-ink-soft"
                  >
                    <span className="text-oxide font-mono shrink-0">→</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              {/* Corner mark */}
              <div className="absolute top-4 right-4 w-3 h-3 border-t border-r border-ink/20 opacity-0 group-hover:opacity-100 transition-opacity" />
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
