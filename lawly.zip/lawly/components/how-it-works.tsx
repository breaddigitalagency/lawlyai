const steps = [
  {
    n: '01',
    title: 'You paste a URL.',
    body: 'Your store homepage. Shopify, WooCommerce, BigCommerce, custom — we crawl what\'s public, the same way Google does.',
    meta: 'Time: 2s',
  },
  {
    n: '02',
    title: 'We run the audit.',
    body: 'Cheerio scrapes your pages. Claude reads your policies. A rules engine flags structural gaps. Findings get severity codes you can sort.',
    meta: 'Time: 20–40s',
  },
  {
    n: '03',
    title: 'You get receipts.',
    body: 'A graded report with the violation, the law it touches, where on your site it lives, and a fix you can actually paste in. No legal jargon.',
    meta: 'Forever yours',
  },
];

export function HowItWorks() {
  return (
    <section id="how" className="py-24 md:py-32 border-t border-ink/15 bg-surface-warm">
      <div className="container-edge">
        <div className="grid grid-cols-12 gap-8 mb-20">
          <div className="col-span-12 md:col-span-7">
            <span className="tag">§ 03 · Method</span>
            <h2 className="font-serif text-display-lg mt-4 text-balance">
              No lawyer. <span className="pull">No upsell.</span>
              <br />
              No 90-page PDF.
            </h2>
          </div>
        </div>

        <ol className="space-y-0">
          {steps.map((step, i) => (
            <li
              key={step.n}
              className="grid grid-cols-12 gap-8 py-12 border-t border-ink/15 last:border-b"
            >
              <div className="col-span-12 md:col-span-3">
                <div className="font-mono text-sm tracking-[0.2em] text-muted">
                  Step {step.n}
                </div>
              </div>

              <div className="col-span-12 md:col-span-6">
                <h3 className="font-serif text-3xl md:text-5xl mb-4 leading-tight">
                  {step.title}
                </h3>
                <p className="text-lg text-ink-soft text-pretty max-w-lg">
                  {step.body}
                </p>
              </div>

              <div className="col-span-12 md:col-span-3 md:text-right">
                <span className="tag border border-ink/20 px-2 py-1">
                  {step.meta}
                </span>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
