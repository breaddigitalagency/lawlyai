'use client';

import { useState } from 'react';

const faqs = [
  {
    q: 'Is this legal advice?',
    a: 'No. Lawly is a diagnostic tool, not a law firm. We flag patterns that map to known regulations so you can either fix them yourself or take the report to an actual attorney. Either way, you go in informed instead of guessing.',
  },
  {
    q: 'What platforms work?',
    a: 'Anything public. Shopify, WooCommerce, BigCommerce, Squarespace, Wix, custom builds. We crawl the same HTML Google sees. If your store is password-protected we can\'t reach it yet — paid plans will support authenticated scans.',
  },
  {
    q: 'How is this different from a Privacy Policy generator?',
    a: 'Generators give you a document. They don\'t tell you the document is missing CCPA opt-out language, or that your refund policy contradicts the Australian Consumer Law, or that your Meta Pixel fires before consent. Lawly reads what you actually shipped.',
  },
  {
    q: 'Do you store my data?',
    a: 'We store the URL you scan and the report we generated, tied to your account if you have one. We don\'t scrape and resell. Your scan history is yours, deletable at any time.',
  },
  {
    q: 'Will this catch every legal issue?',
    a: 'No tool catches everything. Lawly is calibrated for the ~80% of issues that come up in actual FTC actions and consumer-protection complaints. The edge cases still need a human lawyer. We tell you which findings need one.',
  },
  {
    q: 'I\'m in Australia / EU / UK. Will it work?',
    a: 'Yes — we run jurisdiction-specific checks based on your store\'s declared market and detected traffic. Australian Consumer Law, GDPR, UK GDPR, Canadian CASL, and CCPA are all in scope.',
  },
];

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 md:py-32 border-t border-ink/15 bg-surface-warm">
      <div className="container-edge">
        <div className="grid grid-cols-12 gap-8">
          <div className="col-span-12 md:col-span-4">
            <span className="tag">§ 05 · Questions</span>
            <h2 className="font-serif text-display-md mt-4 text-balance sticky top-24">
              The reasonable
              <br />
              <span className="pull">objections.</span>
            </h2>
          </div>

          <div className="col-span-12 md:col-span-8 md:col-start-5">
            <ul className="border-t border-ink/15">
              {faqs.map((faq, i) => {
                const isOpen = open === i;
                return (
                  <li key={i} className="border-b border-ink/15">
                    <button
                      onClick={() => setOpen(isOpen ? null : i)}
                      className="w-full text-left py-6 flex items-start justify-between gap-6 hover:text-oxide transition-colors"
                    >
                      <span className="font-serif text-xl md:text-2xl leading-snug">
                        {faq.q}
                      </span>
                      <span
                        className={`font-mono text-sm shrink-0 mt-2 transition-transform ${
                          isOpen ? 'rotate-45' : ''
                        }`}
                      >
                        +
                      </span>
                    </button>
                    <div
                      className={`grid transition-all duration-300 ease-out ${
                        isOpen ? 'grid-rows-[1fr] pb-8' : 'grid-rows-[0fr]'
                      }`}
                    >
                      <div className="overflow-hidden">
                        <p className="text-ink-soft text-pretty max-w-2xl leading-relaxed">
                          {faq.a}
                        </p>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
