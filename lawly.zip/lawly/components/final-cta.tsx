import { ScanForm } from './scan-form';

export function FinalCta() {
  return (
    <section className="bg-ink text-bone py-24 md:py-32 relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage:
            'radial-gradient(circle at 1px 1px, rgba(245,241,232,1) 1px, transparent 0)',
          backgroundSize: '24px 24px',
        }}
      />

      <div className="container-edge relative">
        <div className="max-w-4xl">
          <span className="tag text-bone/60">§ 06 · One scan</span>
          <h2 className="font-serif text-display-lg mt-4 text-balance">
            See what's broken
            <br />
            before someone <span className="pull text-oxide">else</span> does.
          </h2>
          <p className="text-lg text-bone/70 mt-8 max-w-xl text-pretty">
            Free first audit. Takes thirty seconds. No card. If your store is
            clean, great — you'll have the receipt to prove it.
          </p>

          <div className="mt-12 max-w-xl">
            <ScanForm />
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-ink text-bone/60 border-t border-bone/10 py-10">
      <div className="container-edge flex flex-col md:flex-row md:items-center md:justify-between gap-6">
        <div className="flex items-baseline gap-3">
          <span className="font-serif text-2xl text-bone">Lawly</span>
          <span className="tag text-bone/40">
            © {new Date().getFullYear()} · Built for operators
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-6 text-sm">
          <a href="#" className="hover:text-bone transition-colors">
            Privacy
          </a>
          <a href="#" className="hover:text-bone transition-colors">
            Terms
          </a>
          <a
            href="mailto:hello@lawlyaichecker.com"
            className="hover:text-bone transition-colors"
          >
            hello@lawlyaichecker.com
          </a>
        </div>

        <div className="tag text-bone/40">
          Not a law firm · Diagnostic tool only
        </div>
      </div>
    </footer>
  );
}
