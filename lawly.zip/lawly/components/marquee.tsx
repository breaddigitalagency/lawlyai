const items = [
  'FTC §5 unfair practices',
  'GDPR Art. 13–14 disclosures',
  'CCPA Do-Not-Sell',
  'Australian Consumer Law',
  'Cookie consent under ePrivacy',
  'FTC influencer endorsement guides',
  'Magnuson-Moss Warranty Act',
  'CAN-SPAM',
  'COPPA',
  'FTC unsubstantiated claims',
  'Auto-renewal disclosures',
  'ROSCA negative-option rules',
];

export function Marquee() {
  // Duplicate for seamless loop
  const all = [...items, ...items];

  return (
    <section className="border-y border-ink/15 bg-ink text-bone py-4 overflow-hidden">
      <div className="flex animate-marquee whitespace-nowrap">
        {all.map((item, i) => (
          <div key={i} className="flex items-center shrink-0">
            <span className="px-8 font-mono text-xs tracking-[0.15em] uppercase">
              {item}
            </span>
            <span className="text-oxide">✕</span>
          </div>
        ))}
      </div>
    </section>
  );
}
