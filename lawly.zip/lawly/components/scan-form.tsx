'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface ScanFormProps {
  variant?: 'hero' | 'compact';
}

export function ScanForm({ variant = 'hero' }: ScanFormProps) {
  const router = useRouter();
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!url) return;

    setLoading(true);
    setError(null);

    // Normalize the URL
    let normalized = url.trim();
    if (!/^https?:\/\//i.test(normalized)) {
      normalized = `https://${normalized}`;
    }

    try {
      new URL(normalized);
    } catch {
      setError('That doesn\'t look like a valid URL.');
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: normalized }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Scan failed. Try again in a moment.');
      }

      const data = await res.json();
      router.push(`/scan/${data.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="relative group">
        <div className="absolute -top-3 left-4 bg-bone px-2">
          <span className="tag">store url</span>
        </div>

        <div className="flex flex-col sm:flex-row gap-2 border-2 border-ink p-1.5 bg-surface focus-within:border-oxide transition-colors">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="yourstore.com"
            disabled={loading}
            className="flex-1 px-4 py-3 bg-transparent outline-none font-mono text-base placeholder:text-muted-soft disabled:opacity-50"
            aria-label="Store URL"
          />
          <button
            type="submit"
            disabled={loading || !url}
            className="bg-ink text-bone px-6 py-3 hover:bg-oxide transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium tracking-wide whitespace-nowrap"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <span className="inline-block w-2 h-2 bg-bone animate-pulse-slow" />
                Scanning...
              </span>
            ) : (
              <>Run audit →</>
            )}
          </button>
        </div>

        {/* Scanning line */}
        {loading && (
          <div className="absolute inset-x-0 top-0 bottom-0 overflow-hidden pointer-events-none">
            <div className="absolute inset-x-0 h-px scan-line animate-scan" />
          </div>
        )}
      </div>

      {error && (
        <p className="mt-3 text-sm text-oxide font-mono">{error}</p>
      )}

      {variant === 'hero' && !error && (
        <p className="mt-3 text-xs text-muted font-mono tracking-wide">
          FREE FIRST SCAN · NO SIGN-UP · ~30 SECONDS
        </p>
      )}
    </form>
  );
}
