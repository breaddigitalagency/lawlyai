import { ScanForm } from './scan-form';

export function Hero() {
  return (
    <section id="scan" className="relative overflow-hidden pt-16 pb-24 md:pt-24 md:pb-32">
      {/* Background pattern */}
      <div className="absolute inset-0 pattern-grid opacity-50 pointer-events-none" />

      {/* Top eyebrow */}
      <div className="container-edge relative">
        <div className="flex items-center gap-3 mb-12">
          <span className="inline-block w-2 h-2 bg-oxide animate-pulse-slow" />
          <span className="tag">Confidential · Filed {new Date().toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' }).toUpperCase()}</span>
          <div className="flex-1 rule" />
          <span className="tag opacity-60">Case file 0001 / live</span>
        </div>
      </div>

      {/* Main grid */}
      <div className="container-edge relative grid grid-cols-12 gap-x-8 gap-y-12">
        {/* LEFT — editorial */}
        <div className="col-span-12 lg:col-span-7 space-y-10">
          <h1 className="font-serif text-display-xl text-balance">
            The legal audit
            <br />
            your store{' '}
            <span className="pull text-oxide">hopes</span>
            <br />
            you never run.
          </h1>

          <div className="max-w-xl space-y-4">
            <p className="text-lg md:text-xl text-ink-soft text-pretty leading-relaxed">
              Lawly scans your storefront, policies, and ad claims for the same
              things plaintiffs' lawyers and the FTC look for first.
            </p>
            <p className="text-base text-muted text-pretty">
              Missing disclosures. GDPR &amp; CCPA gaps. Fake urgency timers.
              Unsubstantiated health claims. Tracking pixels without consent.
              Thirty seconds. You see the receipts before they do.
            </p>
          </div>

          <div id="hero-form" className="max-w-xl pt-4">
            <ScanForm />
          </div>
        </div>

        {/* RIGHT — forensic mock report card */}
        <div className="col-span-12 lg:col-span-5 lg:pt-4">
          <ReportPreview />
        </div>
      </div>
    </section>
  );
}

function ReportPreview() {
  return (
    <div className="relative">
      {/* Stamp */}
      <div className="absolute -top-3 -right-3 z-10 rotate-6">
        <div className="border-2 border-oxide text-oxide px-3 py-1 font-mono text-[10px] tracking-[0.2em] uppercase bg-bone/80 backdrop-blur">
          High Risk
        </div>
      </div>

      <div className="bg-surface border border-ink/15 shadow-[0_30px_60px_-20px_rgba(26,22,17,0.15)]">
        {/* Header bar */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-ink/10 bg-bone-deep/40">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-oxide animate-pulse-slow" />
            <span className="tag">Sample report</span>
          </div>
          <span className="font-mono text-[10px] text-muted">LWL-7281-AU</span>
        </div>

        {/* URL line */}
        <div className="px-5 py-3 border-b border-ink/10">
          <div className="text-[10px] tag mb-1">Target</div>
          <div className="font-mono text-sm truncate">store.example.com</div>
        </div>

        {/* Score */}
        <div className="px-5 py-5 border-b border-ink/10 flex items-baseline justify-between">
          <div>
            <div className="tag mb-2">Compliance grade</div>
            <div className="font-serif text-7xl text-oxide leading-none">D−</div>
          </div>
          <div className="text-right">
            <div className="tag mb-2">Issues found</div>
            <div className="font-serif text-5xl text-ink leading-none">14</div>
          </div>
        </div>

        {/* Findings */}
        <ul className="divide-y divide-ink/10">
          <Finding
            severity="critical"
            code="PRV-001"
            text="Privacy Policy missing GDPR lawful-basis clause"
          />
          <Finding
            severity="high"
            code="ADS-012"
            text="Product page claims “clinically proven” with no source"
          />
          <Finding
            severity="high"
            code="CKE-004"
            text="Meta Pixel fires before consent banner is accepted"
          />
          <Finding
            severity="med"
            code="RFD-002"
            text="Refund Policy contradicts the Australian Consumer Law"
          />
          <Finding
            severity="low"
            code="SHP-001"
            text="Shipping timeframes not disclosed before checkout"
          />
        </ul>

        <div className="px-5 py-3 border-t border-ink/10 bg-bone-deep/40 flex items-center justify-between">
          <span className="tag">+ 9 more findings</span>
          <span className="font-mono text-xs text-ink-soft">view full →</span>
        </div>
      </div>
    </div>
  );
}

function Finding({
  severity,
  code,
  text,
}: {
  severity: 'critical' | 'high' | 'med' | 'low';
  code: string;
  text: string;
}) {
  const sev = {
    critical: { label: 'CRIT', cls: 'bg-oxide text-bone' },
    high: { label: 'HIGH', cls: 'bg-oxide/15 text-oxide' },
    med: { label: 'MED', cls: 'bg-gold/20 text-gold-deep' },
    low: { label: 'LOW', cls: 'bg-ink/10 text-ink-soft' },
  }[severity];

  return (
    <li className="px-5 py-3 flex items-start gap-3">
      <span
        className={`shrink-0 mt-0.5 font-mono text-[9px] tracking-wider px-1.5 py-0.5 ${sev.cls}`}
      >
        {sev.label}
      </span>
      <div className="min-w-0 flex-1">
        <div className="text-sm text-ink leading-snug">{text}</div>
        <div className="tag mt-1 opacity-70">{code}</div>
      </div>
    </li>
  );
}
