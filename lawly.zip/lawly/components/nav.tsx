import Link from 'next/link';

export function Nav() {
  return (
    <nav className="border-b border-ink/10 bg-bone/80 backdrop-blur-md sticky top-0 z-50">
      <div className="container-edge flex h-16 items-center justify-between">
        <Link href="/" className="flex items-baseline gap-2 group">
          <span className="font-serif text-2xl tracking-tight">Lawly</span>
          <span className="tag opacity-60 group-hover:opacity-100 transition-opacity">
            /audit
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8 text-sm">
          <a href="#checks" className="hover:text-oxide transition-colors">
            What we check
          </a>
          <a href="#how" className="hover:text-oxide transition-colors">
            How it works
          </a>
          <a href="#pricing" className="hover:text-oxide transition-colors">
            Pricing
          </a>
          <a
            href="#scan"
            className="bg-ink text-bone px-4 py-2 hover:bg-oxide transition-colors text-sm tracking-wide"
          >
            Run a scan →
          </a>
        </div>
      </div>
    </nav>
  );
}
