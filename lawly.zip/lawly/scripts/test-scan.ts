// Quick smoke test of the scanner. Run with: npx tsx scripts/test-scan.ts
import { runScan } from '../lib/scanner';

const TARGET = process.argv[2] || 'https://bombas.com';

async function main() {
  console.log(`\n→ Scanning ${TARGET}\n`);
  const t0 = Date.now();

  try {
    const result = await runScan(TARGET);
    const dt = Date.now() - t0;

    console.log(`Done in ${dt}ms\n`);
    console.log(`Grade:    ${result.grade}`);
    console.log(`Score:    ${result.score}/100`);
    console.log(`Platform: ${result.meta.platform ?? 'unknown'}`);
    console.log(`Jurisdiction: ${result.meta.detectedJurisdiction?.join(', ')}`);
    console.log(`Pages fetched: ${result.meta.pagesFetched}\n`);

    for (const b of result.buckets) {
      console.log(`\n─── ${b.bucket.toUpperCase()} (${b.status}) ───`);
      console.log(`   ${b.passed} passed, ${b.findings.length} findings`);
      for (const f of b.findings) {
        console.log(`   [${f.severity.toUpperCase().padEnd(8)}] ${f.code}  ${f.title}`);
      }
    }
  } catch (err) {
    console.error('Scan failed:', err);
  }
}

main();
